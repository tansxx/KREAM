//
//  RecommendViewController.swift
//  kream
//
//  Created by 강희정 on 10/11/24.
//

import UIKit

class RecommendViewController: UIViewController {
    private let rootView = RecommendView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view = rootView

    }
    

  

}
